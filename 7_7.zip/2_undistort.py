import cv2
import numpy as np
import matplotlib
matplotlib.use('agg')
import matplotlib.pyplot as plt
import matplotlib.image as mpimg

npzfile = np.load("calib_params.npz")

mtx = npzfile['arr_0']
dist = npzfile['arr_1']

#img = cv2.imread('test_images/straight_lines1.jpg')
img = cv2.imread('camera_cal/calibration1.jpg')

undist = cv2.undistort(img, mtx, dist)

fig, axes = plt.subplots(1,2, figsize=(9,3))
axes[0].set_title('before undistortion')
axes[0].imshow(img)
axes[1].set_title('after undistortion')
axes[1].imshow(undist)

plt.savefig('compare.png')
#cv2.imwrite('calibration1_undist.png', undist)
